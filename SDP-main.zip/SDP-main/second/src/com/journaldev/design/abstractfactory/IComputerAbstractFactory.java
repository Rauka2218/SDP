
package com.journaldev.design.abstractfactory;
import com.journaldev.design.model.Computer;
public interface IComputerAbstractFactory {
    Computer createComputer();
}
